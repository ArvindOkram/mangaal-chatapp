// db.js
const mongoose = require('mongoose');

MONGO_CONNECTION_URL = "mongodb+srv://arvindOkram:3hPx48EbZw96NjAi@contact-manager.g0uvowz.mongodb.net/chat-app"
const connectDB = async () => {
  try {
    await mongoose.connect(MONGO_CONNECTION_URL);
    console.log('MongoDB connected');
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
  }
};

module.exports = connectDB;
