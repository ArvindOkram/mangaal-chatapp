const asyncHandler = require("express-async-handler");
const User = require("../models/user-model");

const createUser = asyncHandler(async (req, res) => {
    const { userName, number } = req.body;

    if (!userName || !number ) {
        res.status(400);
        throw new Error("All fields are mandatory");
    }

    const userAvailable = await User.findOne({ number });

    if (userAvailable) {
        res.status(400);
        throw new Error("User already registered!");
    }

    const user = await User.create({
        userName,
        number
    });

    if (user) {
        res.status(201).json({
            id: user.id,
            message: 'User registered successfully'
        })
    } else {
        res.status(400);
        throw new Error("User data is not valid")
    }
})


module.exports = {
    createUser
};