const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const moment = require('moment');
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const router = express.Router();

MONGO_CONNECTION_URL = "mongodb+srv://arvindOkram:3hPx48EbZw96NjAi@contact-manager.g0uvowz.mongodb.net/chat-app"

mongoose.connect(MONGO_CONNECTION_URL);
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));

const messageSchema = new mongoose.Schema({
  username: String,
  message: String,
  sendto: String,
  timestamp: { type: Date, default: Date.now },
  expiresAt: Date
});

const Message = mongoose.model('Message', messageSchema);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));


app.get('/messages/:user', async (req, res) => {
  try {
    
    const messages = await Message.find({  expiresAt: { $gt: new Date() } }).sort({ timestamp: -1 }).limit(10).exec();
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/messages', async (req, res) => {
  try {
    console.log(req.body);
    const { username, message, sendto } = req.body;
    const expiresAt = moment().add(1, 'minute').toDate();
    console.log(expiresAt);
    const newMessage = new Message({ username, message, sendto, expiresAt });
    await newMessage.save();
    //io.emit('chatMessage', { username, message, expiresAt });
    res.status(201).json(newMessage);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

io.on('connection', (socket) => {
  console.log('a user connected');

  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

setInterval(() => {
  Message.deleteMany({ expiresAt: { $lt: new Date() } });
}, 60000);
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
